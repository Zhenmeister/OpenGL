#include "FlyCam.h"
//#include <iostream>


double FlyCam::mouse_scrollX = 0.0;
double FlyCam::mouse_scrollY = 0.0;
double FlyCam::mouse_PosX = 0.0;
double FlyCam::mouse_PosY = 0.0;
double FlyCam::mouse_oldPosX = 0.0;
double FlyCam::mouse_oldPosY = 0.0;

int FlyCam::moveCount = 0;

FlyCam::FlyCam()
{
}


FlyCam::~FlyCam()
{
}

void cursorCallback(GLFWwindow* window, double x, double y)
{
	FlyCam::mouse_oldPosX = FlyCam::mouse_PosX;
	FlyCam::mouse_oldPosY = FlyCam::mouse_PosY;

	FlyCam::mouse_PosX = x;
	FlyCam::mouse_PosY = y;

	if(FlyCam::moveCount < 2)
		FlyCam::moveCount++;
}
void scrollCallback(GLFWwindow* window, double x, double y)
{
	FlyCam::mouse_scrollX = x;
	FlyCam::mouse_scrollY = y;

	//std::cout << x << "__" << y << std::endl;
}

void FlyCam::Update(float deltaTime, GLFWwindow* window)
{
	glfwSetScrollCallback(window, scrollCallback);

	glfwSetCursorPosCallback(window, cursorCallback);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		getWorldTransform() = glm::translate(getWorldTransform(), vec3(0, 1, 0));
	}

	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
	{
		getWorldTransform() = glm::translate(getWorldTransform(), vec3(-1, 0, 0));
	}

	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
	{
		getWorldTransform() = glm::translate(getWorldTransform(), vec3(1, 0, 0));
	}

	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		getWorldTransform() = glm::translate(getWorldTransform(), vec3(0, -1, 0));
	}

	if (FlyCam::moveCount == 2)
	{
		float moveX = mouse_PosX - mouse_oldPosX;
		float moveY = mouse_PosY - mouse_oldPosY;

		mouse_oldPosY = 500.0;
		mouse_oldPosX = 500.0;
		mouse_PosY = 500.0;
		mouse_PosX = 500.0;

		if (moveY != 0.0f && glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_1) == GLFW_PRESS)
		{
			getWorldTransform() = glm::rotate(getWorldTransform(), moveY / 1000.0f, vec3(-1, 0, 0));
		}

		if (moveX != 0.0f && glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_1) == GLFW_PRESS)
		{
			vec3 axis(vec4(0, -1, 0, 1) * getWorldTransform());
			getWorldTransform() = glm::rotate(getWorldTransform(), moveX / 1000.0f, axis);
		}
	}

	if (FlyCam::mouse_scrollY != 0.0)
	{
		getWorldTransform() = glm::translate(getWorldTransform(), vec3(0, 0, -1)* FlyCam::mouse_scrollY);
		FlyCam::mouse_scrollY = 0.0;
	}

	if(glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_1) == GLFW_PRESS)
		glfwSetCursorPos(window, 500.0, 500.0);

	updateProjectionViewTransform();
}

void setSpeed(float speed)
{

}