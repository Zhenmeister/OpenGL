#pragma once
#include "Camera.h"


class FlyCam : public Camera
{
public:
	FlyCam();
	~FlyCam();

	void Update(float deltaTime, GLFWwindow* window);
	void setSpeed(float speed);

	static double mouse_scrollX, mouse_scrollY;
	static double mouse_PosX, mouse_PosY;
	static double mouse_oldPosX, mouse_oldPosY;

	static int moveCount;

private:

	float speed;
	vec3 up;

	

};

