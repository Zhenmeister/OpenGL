#include "Quaternion.h"



Quaternion::Quaternion()
{
	m_position[0] = glm::vec3(10, 5, 10);
	m_position[1] = glm::vec3(-10, 0, -10);

	m_rotation[0] = glm::quat(glm::vec3(0, -1, 0));
	m_rotation[1] = glm::quat(glm::vec3(0, 1, 0));
}


Quaternion::~Quaternion()
{
}
