#pragma once
#include <GLM/gtc/quaternion.hpp>
#include <GLM/gtx/quaternion.hpp>
class Quaternion
{
public:
	Quaternion();
	~Quaternion();


private:
	glm::vec3 m_position[3];
	glm::quat m_rotation[2];

	

};

