#include "Camera.h"
#include <iostream>
#include <GLM\gl_core_4_4.h>
#include <GLFW\glfw3.h>
#include <AIE/Gizmos.h>
#include <glm/glm.hpp>
#include <glm/ext.hpp>

using glm::vec3;
using glm::vec4;
using glm::mat4;



Camera::Camera()
{
	 viewTransform = glm::lookAt(vec3(10, 10, 10), vec3(0), vec3(0, 1, 0));
	 projectionTransform = glm::perspective(glm::pi<float>() * 0.25f, 16 / 9.f, 0.1f, 1000.f);
}


Camera::~Camera()
{
}

void Camera::setPerspective(float fieldOfView, float aspectRatio, float _near, float _far)
{
	projectionTransform = glm::perspective(fieldOfView, aspectRatio, _near, _far);	

}

void Camera::setLookAt(vec3 from, vec3 to, vec3 up)
{
	viewTransform = glm::lookAt(from, to, up);
}

void Camera::setPosition(vec3 position)
{
	
}

mat4 Camera::getWorldTransform()
{
	return mat4();
}

mat4 Camera::getView()
{
	return mat4();
}

mat4 Camera::getProjection()
{
	return mat4();
}

mat4 Camera::getProjectionView()
{
	return mat4();
}

void Camera::updateProjectionViewTransform()
{

}
