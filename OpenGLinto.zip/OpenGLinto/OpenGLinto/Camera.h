#pragma once
#include <GLM\gl_core_4_4.h>
#include <GLFW\glfw3.h>
#include <AIE/Gizmos.h>
#include <glm/glm.hpp>
#include <glm/ext.hpp>

using glm::mat4;
using glm::vec3;
using glm::vec4;

class Camera
{
public:
	Camera();
	~Camera();

	virtual void Update(float deltaTime) = 0;

	void setPerspective(float fieldOfView, float aspectRatio, float _near, float _far);
	void setLookAt(vec3 from, vec3 to, vec3 up);
	void setPosition(vec3 position);
	mat4 getWorldTransform();
	mat4 getView();
	mat4 getProjection();
	mat4 getProjectionView();

	void updateProjectionViewTransform();


	

private:
	mat4 worldTransform;
	mat4 viewTransform;
	mat4 projectionTransform;
	mat4 projectionViewTransform;

	
};

