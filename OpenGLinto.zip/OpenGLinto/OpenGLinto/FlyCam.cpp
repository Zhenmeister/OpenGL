#include "FlyCam.h"



FlyCam::FlyCam()
{
}


FlyCam::~FlyCam()
{
}
