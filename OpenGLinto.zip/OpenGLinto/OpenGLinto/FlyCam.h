#pragma once
#include "Camera.h"


class FlyCam : Camera
{
public:
	FlyCam();
	~FlyCam();

	void Update(float deltaTime);
	void setSpeed(float speed);

private:

	float speed;
	vec3 up;
};

