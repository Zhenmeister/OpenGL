#include <iostream>
#include <GLM\gl_core_4_4.h>
#include <GLFW\glfw3.h>
#include <AIE/Gizmos.h>
#include <glm/glm.hpp>
#include <glm/ext.hpp>

using glm::vec3;
using glm::vec4;
using glm::mat4;

int main()
{

	if (glfwInit() == false)
	{
		return -1;
	}

	GLFWwindow* window = glfwCreateWindow(1280, 720, "Computer Graphics", nullptr, nullptr);

	if (window == nullptr)
	{
		glfwTerminate();
		return -2;
	}

	glfwMakeContextCurrent(window);

	//Fixed OpenGL extensions
	if (ogl_LoadFunctions() == ogl_LOAD_FAILED)
	{
		glfwDestroyWindow(window);
		glfwTerminate();
			return -3;
	}
	//Tests what version of OpenGL is running.
	auto major = ogl_GetMajorVersion();
	auto minor = ogl_GetMinorVersion();
	printf("GL: %i.%i\n", major, minor);

	//Specifies the colour of our screen.
	glClearColor(0.25f, 0.25f, 0.25f, 1);

	//Adding Gizmos so that we use it to create a 3-D camera.
	Gizmos::create();
	
	

	glm::mat4 test(1); //Create a matrix
	glm::mat4 test1(1); //Create a matrix
	float time = 0;


	//Our GAME LOOP!!!
	while (glfwWindowShouldClose(window) == false &&
		glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS)
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);			//informs OpenGL to wipe the back-buffer colours clean. | informs it to clearthe distance to the closest pixels.


		Gizmos::clear();

		Gizmos::addTransform(glm::mat4(1));

		vec4 white(1);
		vec4 black(0, 0, 0, 1);
		//Creates a 3-D grid
		for (int i = 0; i < 21; ++i)
		{
			Gizmos::addLine(vec3(-10 + i, 0, 10),
				vec3(-10 + i, 0, -10),
				i == 10 ? white : black);

			Gizmos::addLine(vec3(10, 0, -10 + i),
				vec3(-10, 0, -10 + i),
				i == 10 ? white : black);
		}

		time += 0.01f;
		test = glm::rotate(test, 0.3f , vec3(0,1,0));
		test1 = glm::rotate(test1, 0.5f, vec3(0, 1, 0));
		

		
		Gizmos::addSphere(vec3(sin(time) * 8,0, cos(time) * 8), 1.5f, 40, 40, vec4(1,1,0,1), &test, 0.0f, 360.0f, -90.0f, 90.0f);
		

		Gizmos::addSphere(vec3(sin(time) * 8, 0, cos(time) * 8) + vec3(sin(time *2) *4, 0, cos(time * 2) * 4), 0.5f, 40, 40, vec4(0,0,1,1), &test1, 0.0f, 360.0f, -90.0f, 90.0f);
		Gizmos::addAABBFilled(vec3(sin(time) * 8, 0, cos(time) * 8) + vec3(sin(time * 2 + 1.5) * 4, 0, cos(time * 2 + 1.5) * 4), vec3(0.5,0.5,0.5), vec4(0, 0, 1, 1), &test);

		Gizmos::draw(projection * view);
		//Depth buffer is off by default, so we must enable it.
		glClearColor(0.25f, 0.25f, 0.25f, 1);
		glEnable(GL_DEPTH_TEST); //enables the depth buffer.

		// our game logic and update code goes here!
		//so does our render code!

		glfwSwapBuffers(window);
		glfwPollEvents();

	}

	//Destory the Gozmos
	Gizmos::destroy();

	//rest of codes goes here!


	glfwDestroyWindow(window);
	glfwTerminate();
	return 0;
}